import path from 'path';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
  server: {
    proxy: {
      '/api/planning': {
        target: 'https://api.apps1.nsw.gov.au/planning/viewersf/V1/ePlanningApi',
        changeOrigin: true,
        secure: false,
        rewrite: (path) => path.replace(/^\/api\/planning/, ''),
        configure: (proxy, _options) => {
          proxy.on('proxyReq', (proxyReq, _req, _res) => {
            proxyReq.setHeader('Accept', 'application/json');
            proxyReq.setHeader('Content-Type', 'application/json');
          });
        }
      },
      '/api/eplanning': {
        target: 'https://api.apps1.nsw.gov.au/eplanning',
        changeOrigin: true,
        secure: false,
        rewrite: (path) => path.replace(/^\/api\/eplanning/, ''),
        configure: (proxy, _options) => {
          proxy.on('proxyReq', (proxyReq, req, _res) => {
            if (req.headers.epiname) {
              proxyReq.setHeader('EpiName', req.headers.epiname);
            }
            if (req.headers.zonecode) {
              proxyReq.setHeader('ZoneCode', req.headers.zonecode);
            }
            proxyReq.setHeader('Accept', 'application/json');
            proxyReq.setHeader('Content-Type', 'application/json');
          });
        }
      }
    }
  }
});
