import express from 'express';
import { createServer as createViteServer } from 'vite';
import apiRoutes from './src/api';

async function createServer() {
  const app = express();
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa'
  });

  app.use(vite.middlewares);
  app.use('/api', apiRoutes);

  app.listen(5173, () => {
    console.log('Server running at http://localhost:5173');
  });
}

createServer(); 