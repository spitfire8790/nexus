import { MapView } from './map-view';

export function MapLayout() {
  return (
    <div className="h-full w-full">
      <MapView />
    </div>
  );
}