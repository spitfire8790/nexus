import { Development as DevelopmentComponent } from './development/development';
export { DevelopmentComponent as Development };