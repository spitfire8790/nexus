export const councils = [
  "Albury City",
  "Armidale Regional",
  "Ballina Shire",
  // ... rest of the councils list
  "Yass Valley"
];